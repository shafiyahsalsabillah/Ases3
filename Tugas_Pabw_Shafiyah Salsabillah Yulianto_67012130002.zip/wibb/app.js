const express = require('express');
const bodyParser = require('body-parser');
const { check, validationResult } = require('express-validator');
const mysql = require('mysql2');

const app = express();
const port = 3000;

// Konfigurasi MySQL
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root', // Ganti dengan username MySQL Anda
  password: '', // Ganti dengan password MySQL Anda
  database: 'pabw', // Ganti dengan nama basis data MySQL Anda
});

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Konfigurasi EJS sebagai view engine
app.set('view engine', 'ejs');

// Menampilkan halaman utama
app.get('/', (req, res) => {
  res.render('index');
});

// Menampilkan semua data telur asin
app.get('/api/telur-asin', (req, res) => {
  const query = 'SELECT * FROM telur_asin';

  connection.query(query, (err, results) => {
    if (err) throw err;

    res.json(results);
  });
});

// Menambahkan data telur asin
app.post(
  '/api/telur-asin',
  [
    check('nama').notEmpty().withMessage('Nama harus diisi'),
    check('jumlah').notEmpty().withMessage('Jumlah harus diisi'),
    check('harga').notEmpty().withMessage('Harga harus diisi'),
  ],
  (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { nama, jumlah, harga } = req.body;
    const query = 'INSERT INTO telur_asin (nama, jumlah, harga) VALUES (?, ?, ?)';

    connection.query(query, [nama, jumlah, harga], (err, results) => {
      if (err) throw err;

      res.sendStatus(201);
    });
  }
);

// Mengubah data telur asin
app.put(
  '/api/telur-asin/:id',
  [
    check('nama').notEmpty().withMessage('Nama harus diisi'),
    check('jumlah').notEmpty().withMessage('Jumlah harus diisi'),
    check('harga').notEmpty().withMessage('Harga harus diisi'),
  ],
  (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const { nama, jumlah, harga } = req.body;
    const query = 'UPDATE telur_asin SET nama = ?, jumlah = ?, harga = ? WHERE id = ?';

    connection.query(query, [nama, jumlah, harga, id], (err, results) => {
      if (err) throw err;

      if (results.affectedRows === 0) {
        return res.sendStatus(404);
      }

      res.sendStatus(204);
    });
  }
);

// Menghapus data telur asin
app.delete('/api/telur-asin/:id', (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM telur_asin WHERE id = ?';

  connection.query(query, [id], (err, results) => {
    if (err) throw err;

    if (results.affectedRows === 0) {
      return res.sendStatus(404);
    }

    res.sendStatus(204);
  });
});

// Jalankan server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
